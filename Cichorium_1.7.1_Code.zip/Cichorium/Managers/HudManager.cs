﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cichorium.Managers
{
    public class HudManager : DrawableGameComponent
    {

        new private Cichorium Game;
        private SpriteBatch spriteBatch;
        private ContentManager ContentManager;

        private float Scale;

        private Texture2D heart_empty;
        private Texture2D heart_full;

        public long TotalFrames { get; private set; }
        public float TotalSeconds { get; private set; }
        public float AverageFramesPerSecond { get; private set; }
        public float CurrentFramesPerSecond { get; private set; }

        public const int MAXIMUM_SAMPLES = 100;

        private Queue<float> _sampleBuffer = new Queue<float>();

        public HudManager(Cichorium game) : base(game)
        {
            Game = game;
            
            ContentManager = Game.Content;
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(Game.GraphicsDevice);

            heart_empty = ContentManager.Load<Texture2D>("heart_empty");
            heart_full = ContentManager.Load<Texture2D>("heart_full");

            base.LoadContent();

        }

        public override void Draw(GameTime gameTime)
        {

            spriteBatch.Begin(samplerState: SamplerState.PointClamp ,transformMatrix: Matrix.CreateScale(Scale));
            DrawHealthBar();
            spriteBatch.End();


            spriteBatch.Begin(samplerState: SamplerState.PointClamp);
            spriteBatch.DrawString(Cichorium.TextureManager.Fonts["default"], "FPS: " + Math.Round(1 / (double)gameTime.ElapsedGameTime.TotalSeconds, 0) + "", new Vector2(10, 75), Color.Black);
            spriteBatch.End();


            base.Draw(gameTime);
        }

        public void DrawHealthBar()
        {
            int offsetX = 2;
            int offsetY = 2;
            int heartWidth = 9;

            for (int i = 0; i < SaveFileManager.Data.HealthScale; i++)
            {
                spriteBatch.Draw(heart_empty, new Vector2(heartWidth * i + offsetX + i, offsetY), Color.White);
            }

            for (int i = 0; i < SaveFileManager.Data.Health; i++)
            {
                spriteBatch.Draw(heart_full, new Vector2(heartWidth * i + offsetX + i, offsetY), Color.White);
            }

        }

        public override void Update(GameTime gameTime)
        {

            Scale = SceneManager.Camera.Scale;

            if (SaveFileManager.TreeData.Skills[2].Unlocked)
            {
                SaveFileManager.Data.HealthScale = 4;
            }

            base.Update(gameTime);
        }

    }
}
