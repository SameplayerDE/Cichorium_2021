﻿using System;
using System.Xml;
using System.Xml.Serialization;
using System.IO;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Media;
using Cichorium.Data;
using Cichorium.Objects;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json;
using tainicom.Aether.Physics2D.Dynamics;
using System.Security.Cryptography;
using Cichorium.Objects.ScreenObjects;
using System.Collections.Generic;

namespace Cichorium.Managers
{
    public static class SaveFileManager
    {

        public static PlayerData Data;
        public static SkillTreeData TreeData;

        public static PlayerData Load()
        {

            if (!File.Exists("playerData.json"))
            {
                Data = new PlayerData();
                Data.Region = "A";
                Data.Health = 1;
                Data.HealthScale = 3;
                Data.SkillPoints = 100;

                SkillTreeData skillTreeData = new SkillTreeData();
                skillTreeData.Skills = new List<SkillData>()
                {
                    {new SkillData("Turnschuh I", "SpeedSkill", false, false, 1, 0)},
                    {new SkillData("Turnschuh II", "SpeedSkill", true, false, 2, 0)},
                    {new SkillData("Rucksack I", "BagSkill", true, false, 2, 1)},
                    {new SkillData("Rucksack II", "BagSkill", true, false, 6, 2)},
                    {new SkillData("Taschendieb I", "BagSkill", true, false, 8, 2)},
                    {new SkillData("Feilcher I", "HeartSkill", true, false, 5, 2)},
                    {new SkillData("Guter Freund I", "HeartSkill", true, false, 8, 5)}
                };

                Data.SkillTree = skillTreeData;
                Save(false);

            }

            using (Stream stream = File.OpenRead("playerData.json"))
            {
                using (StreamReader sr = new StreamReader(stream))
                {
                    string json = sr.ReadToEnd();

                    Data = JsonConvert.DeserializeObject<PlayerData>(json);
                    TreeData = Data.SkillTree;

                    if (TreeData.Skills[2].Unlocked)
                    {
                        Data.HealthScale = 4;
                    }

                    return Data;

                }
            }
        }

        public static void Save(bool region)
        {

            JsonSerializer serializer = new JsonSerializer();
            serializer.Formatting = Newtonsoft.Json.Formatting.Indented;
            serializer.NullValueHandling = NullValueHandling.Ignore;

            if (region)
                Data.Region = Cichorium.SimulationManager.CurrentRegion.Title;

            using (StreamWriter sw = new StreamWriter("playerData.json"))
            {
                using (JsonWriter writer = new JsonTextWriter(sw))
                {
                    serializer.Serialize(writer, Data);
                }
            }
        }
    }
}
