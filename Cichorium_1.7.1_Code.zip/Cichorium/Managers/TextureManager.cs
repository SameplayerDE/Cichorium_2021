﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cichorium.Managers
{
    public class TextureManager
    {

        public bool Loaded = false;
        public Dictionary<string, Texture2D> Sprites { get; private set; } = new Dictionary<string, Texture2D>();
        public Dictionary<string, SpriteFont> Fonts { get; private set; } = new Dictionary<string, SpriteFont>();

        public void LoadContent(ContentManager Content)
        {
            Sprites.Add("pixel", Content.Load<Texture2D>("pixel"));
            Sprites.Add("tiles", Content.Load<Texture2D>("trey"));
            Sprites.Add("player", Content.Load<Texture2D>("player_sheet"));
            Sprites.Add("frog", Content.Load<Texture2D>("frog"));
            Sprites.Add("smoke", Content.Load<Texture2D>("smoke"));
            Sprites.Add("fly", Content.Load<Texture2D>("fly"));
            Sprites.Add("panel", Content.Load<Texture2D>("ui_panel"));

            for (int y = 0; y < Sprites["panel"].Height / 7; y++)
            {
                for (int x = 0; x < Sprites["panel"].Width / 7; x++)
                {
                    Texture2D cropTexture = new Texture2D(Cichorium.Instance.GraphicsDevice, 7, 7);
                    Color[] data = new Color[7 * 7];
                    Sprites["panel"].GetData(0, new Rectangle(x * 7, y * 7, 7, 7), data, 0, data.Length);
                    cropTexture.SetData(data);
                    Console.WriteLine((y * 3 + x));
                    Sprites.Add("panel-" + (y * 3 + x), cropTexture);
                }
            }

            Sprites.Add("button", Content.Load<Texture2D>("ui_button"));

            for (int y = 0; y < Sprites["button"].Height / 7; y++)
            {
                for (int x = 0; x < Sprites["button"].Width / 7; x++)
                {
                    Texture2D cropTexture = new Texture2D(Cichorium.Instance.GraphicsDevice, 7, 7);
                    Color[] data = new Color[7 * 7];
                    Sprites["button"].GetData(0, new Rectangle(x * 7, y * 7, 7, 7), data, 0, data.Length);
                    cropTexture.SetData(data);
                    Console.WriteLine((y * 3 + x));
                    Sprites.Add("button-" + (y * 3 + x), cropTexture);
                }
            }

            Sprites.Add("lockedSkill", Content.Load<Texture2D>("lockedSkill"));
            Sprites.Add("unlockedHealthSkill", Content.Load<Texture2D>("unlockedHealthSkill"));
            Sprites.Add("lockedHealthSkill", Content.Load<Texture2D>("lockedHealthSkill"));
            Sprites.Add("lockedDefenseSkill", Content.Load<Texture2D>("lockedDefenseSkill"));
            Sprites.Add("unlockedDefenseSkill", Content.Load<Texture2D>("unlockedDefenseSkill"));
            Sprites.Add("lockedSpeedSkill", Content.Load<Texture2D>("lockedSpeedSkill"));
            Sprites.Add("unlockedSpeedSkill", Content.Load<Texture2D>("unlockedSpeedSkill"));
            Sprites.Add("lockedBagSkill", Content.Load<Texture2D>("lockedBagSkill"));
            Sprites.Add("unlockedBagSkill", Content.Load<Texture2D>("unlockedBagSkill"));
            Fonts.Add("text", Content.Load<SpriteFont>("text"));
            Fonts.Add("default", Content.Load<SpriteFont>("default"));
            Loaded = true;
        }

    }
}
