﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Cichorium.Objects.ScreenObjects
{
    public class Container : ScreenObject
    {

        private readonly int Scale = 3;
        private int Width = 100, Height = 100;
        private List<ScreenObject> ScreenObjects = new List<ScreenObject>();

        public Container(int x, int y)
        {
            Position = new Point(x, y);
        }

        public void Add(ScreenObject screenObject)
        {
            screenObject.Position = (screenObject.Position.ToVector2() + Position.ToVector2()).ToPoint();
            ScreenObjects.Add(screenObject);
        }

        public override void Draw(SpriteBatch spriteBatch)
        {

            spriteBatch.Draw(Cichorium.TextureManager.Sprites["panel-0"], new Rectangle(Position.X - (7 * Scale), Position.Y - (7 * Scale), 7 * Scale, 7 * Scale), Color.White);
            spriteBatch.Draw(Cichorium.TextureManager.Sprites["panel-1"], new Rectangle(Position.X, Position.Y - (7 * Scale), Width * Scale, 7 * Scale), Color.White);
            spriteBatch.Draw(Cichorium.TextureManager.Sprites["panel-2"], new Rectangle(Position.X + Width * Scale, Position.Y - (7 * Scale), 7 * Scale, 7 * Scale), Color.White);

            spriteBatch.Draw(Cichorium.TextureManager.Sprites["panel-3"], new Rectangle(Position.X - (7 * Scale), Position.Y, 7 * Scale, Height * Scale), Color.White);
            spriteBatch.Draw(Cichorium.TextureManager.Sprites["panel-4"], new Rectangle(Position.X, Position.Y, Width * Scale, Height * Scale), Color.White);
            spriteBatch.Draw(Cichorium.TextureManager.Sprites["panel-5"], new Rectangle(Position.X + Width * Scale, Position.Y, 7 * Scale, Height * Scale), Color.White);

            spriteBatch.Draw(Cichorium.TextureManager.Sprites["panel-6"], new Rectangle(Position.X - (7 * Scale), Position.Y + Height * Scale, 7 * Scale, 7 * Scale), Color.White);
            spriteBatch.Draw(Cichorium.TextureManager.Sprites["panel-7"], new Rectangle(Position.X, Position.Y + Height * Scale, Width * Scale, 7 * Scale), Color.White);
            spriteBatch.Draw(Cichorium.TextureManager.Sprites["panel-8"], new Rectangle(Position.X + Width * Scale, Position.Y + Height * Scale, 7 * Scale, 7 * Scale), Color.White);

            foreach (var obj in ScreenObjects)
            {
                if (obj.Visible)
                    obj.Draw(spriteBatch);
            }

        }

        public override void Update(GameTime gameTime)
        {
            foreach (var obj in ScreenObjects)
            {
                obj.Update(gameTime);
            }
        }
    }
}
