﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Cichorium.Objects.ScreenObjects
{
    public class Image : ScreenObject
    {

        protected Texture2D texture;
        protected Color Color = Color.White;
        protected float Alpha = 1f;
        protected Rectangle ImageArea;
        protected float Scale = 3;

        public Image(string source)
        {
            texture = Cichorium.TextureManager.Sprites[source];
        }

        public void SetSource(string source)
        {
            texture = Cichorium.TextureManager.Sprites[source];
        }

        public Image(int x, int y, string source)
        {
            Position = new Point(x, y);
            texture = Cichorium.TextureManager.Sprites[source];
        }

        public override void Draw(SpriteBatch spriteBatch)
        {
            //spriteBatch.Draw(texture, ImageArea, Color * Alpha);
            spriteBatch.Draw(texture, Container.Position.ToVector2() + Position.ToVector2(), null, Color * Alpha, 0, texture.Bounds.Center.ToVector2(), Scale, SpriteEffects.None, 0);
        }

        public override void Update(GameTime gameTime)
        {

            ImageArea = new Rectangle(Container.Position + Position - ((texture.Bounds.Size.ToVector2() * Scale) / 2).ToPoint(), (texture.Bounds.Size.ToVector2() * Scale).ToPoint());

        }

    }
}
