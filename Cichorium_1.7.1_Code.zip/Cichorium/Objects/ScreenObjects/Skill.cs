﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Cichorium.Managers;

namespace Cichorium.Objects.ScreenObjects
{
    public class Skill : Image
    {

        public SkillData Data;

        public bool Hover = false;

        public Skill(ref SkillData Data) : base(Data.GetCalculatedSourcename())
        {
            this.Data = Data;
        }

        public Skill(int x, int y, ref SkillData Data) : base(x, y, Data.GetCalculatedSourcename())
        {
            this.Data = Data;
        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);

            SetSource(Data.GetCalculatedSourcename());

            if (ImageArea.Contains(Container.latestMouseState.Position))
            {
                Hover = true;
                if (!Data.Locked && !Data.Unlocked)
                {
                    Scale = 3.5f;
                    if (Cichorium.InputManager.IsActionTriggered((int)Cichorium.Actions.LeftClicked))
                    {
                        if (Data.SkillPointCosts <= SaveFileManager.Data.SkillPoints)
                        {
                            Data.Buy();
                            SkillManager.Update();
                        }
                    }
                }
            }
            else
            {
                Hover = false;
                if (!Data.Locked) Scale = 3f;
            }
        }

    }

    public class SkillData
    {

        public string Displayname;
        public string Sourcename;
        public bool Locked;
        public bool Unlocked;

        public int Parent;

        public int SkillPointCosts;

        public SkillData(string Displayname, string Sourcename, bool Locked, bool Unlocked, int SkillPointCosts, int Parent)
        {
            this.Displayname = Displayname;
            this.Sourcename = Sourcename;
            this.Locked = Locked;
            this.Unlocked = Unlocked;
            this.SkillPointCosts = SkillPointCosts;
            this.Parent = Parent;
        }

        public string GetCalculatedSourcename()
        {
            if (Locked) return "lockedSkill";
            if (!Unlocked) return "locked" + Sourcename;
            return "unlocked" + Sourcename;
        }

        public void Update()
        {
            if (SkillManager.Skills[Parent].Unlocked)
            {
                Unlock();
            }
        }

        public void Unlock()
        {
            Locked = false;
        }

        public void Buy()
        {
            Unlocked = true;
            SaveFileManager.Data.SkillPoints -= SkillPointCosts;
            Cichorium.Skills.UpdatePoints();
            Cichorium.AudioManager.SoundEffects["skill_unlocked"].Play();
        }

    }
}
