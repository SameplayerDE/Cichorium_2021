﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Cichorium.Managers;
using Cichorium.Objects.ScreenObjects;

namespace Cichorium.Objects.Screens
{
    public class PauseScreen : Screen
    {

        public Button Exit;
        public Button Save;
        public Container Container;

        public PauseScreen() : base(2)
        {
            Exit = new Button(0, 59 * 2, "Exit");
            Save = new Button(0, 59 - 1, "Save");
            Container = new Container(100, 100);

            Container.Add(new Label(0, 0, "Pause"));
            Container.Add(Save);
            Container.Add(Exit);

            Add(Container);
            
        }

        

    }
}
