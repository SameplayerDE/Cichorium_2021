﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Cichorium.Managers;
using Cichorium.Objects.ScreenObjects;

namespace Cichorium.Objects.Screens
{
    public class SkillTreeScreen : DragableScreen
    {

        private int scale = 3;
        private Label points;
        private Label displayname;
        private Label costs;

        private static List<Point> positions = new List<Point>()
        {
            { Cichorium.Middle }, //Speed
            { Cichorium.Middle + new Point(1 * (32 * 3), 0 * (32 * 3)) }, //Speed 2
            { Cichorium.Middle + new Point(1 * (16 * 3), -1 * (32 * 3)) }, //More Items 
            { Cichorium.Middle + new Point(1 * (16 * 3), -2 * (32 * 3)) }, //More Items 2
            { Cichorium.Middle + new Point(3 * (16 * 3), -3 * (16 * 3)) },
            { Cichorium.Middle + new Point(3 * (16 * 3), 1 * (32 * 3)) },
            { Cichorium.Middle + new Point(3 * (16 * 3), 2 * (32 * 3)) },
        };

        public SkillTreeScreen() : base(1)
        {
            DrawBackground = true;
            Position = new Point(0, 0);
            Size = Cichorium.Scale;
            Alpha = 0.9f;
            Color = Color.Black;

            displayname = new Label("name");
            displayname.Color = Color.Yellow;
            costs = new Label("costs");
            costs.Color = Color.Crimson;

            int loop = 0;
            foreach (SkillData Skill in SkillManager.Skills)
            {
                Add(SkillManager.GetSkillWithPosition(positions[loop].X, positions[loop].Y, loop));
                loop++;
            }

            points = new Label("Points: " + SaveFileManager.Data.SkillPoints) { Color = Color.Yellow};

        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);

            foreach (var obj in Components)
            {
                if (obj is Skill)
                {
                    Skill s = obj as Skill;

                    displayname.Visible = false;
                    costs.Visible = false;

                    if (s.Hover)
                    {

                        displayname.SetText(s.Data.Displayname);
                        costs.SetText("Costs: " + s.Data.SkillPointCosts);

                        if (s.Data.SkillPointCosts <= SaveFileManager.Data.SkillPoints)
                        {
                            costs.Color = Color.LawnGreen;
                        }
                        else
                        {
                            costs.Color = Color.Crimson;
                        }

                        displayname.Update(gameTime);
                        costs.Update(gameTime);

                        if (!s.Data.Locked) displayname.Visible = true;
                        if (!s.Data.Locked &&!s.Data.Unlocked) costs.Visible = true;

                        displayname.SetPosition(latestMouseState.Position + new Point(5, 5));
                        costs.SetPosition(displayname.Position + new Point(0, 10 + displayname.Size.Y));
                        return;
                    }
                   
                }
            }

        }

        public void UpdatePoints()
        {
            points.SetText("Points: " + SaveFileManager.Data.SkillPoints);
        }

        public void UpdateSkillTree()
        {
            RemoveAll();
            int loop = 0;
            foreach (SkillData Skill in SkillManager.Skills)
            {
                Add(SkillManager.GetSkillWithPosition(positions[loop].X, positions[loop].Y, loop));
                loop++;
            }
            
            Add(points);
            Add(displayname);
            Add(costs);
        }

    }


}
